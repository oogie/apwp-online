README

Vaes et al. (2023) - EarthArXiv
A global apparent polar wander path for the last 320 Ma calculated from site-level paleomagnetic data.
https://doi.org/10.31223/X55368

Last updated: 15 February 2023

----

This .zip file contains three files:
1) Reference_database_Vaes_et_al_2023: The reference database of paleomagnetic poles used to compute the global APWP for the last 320 Ma.
2) Global_plate_circuit_Vaes_et_al_2023: The global plate circuit of Euler rotation poles that are used to transfer re-sampled virtual geomagnetic poles (VGPs) to a chosen reference plate. Note that South Africa (701) is at the base of the reconstruction tree.
3) Global_APWP_Vaes_et_al_2023: The new global APWP for the last 320 Ma in the coordinates of South Africa, North America, South America, Eurasia, India, Australia, Antarctica and the Pacific Plate.

For more details, and an explanation of the parameters listed in these files, we refer you to the paper.

For any questions or comments, please contact Bram Vaes (b.vaes@uu.nl).